#' @title STID: Spatial Transcriptomics toolkit for Infectious Diseases
#'
#' @description
#' A comprehensive toolkit for quality control, analysis, and exploration of spatial transcriptomics data.
#' 'STID' aims to enable users to identify spatial niches, interpret cell-cell communication contexts,
#' and integrate diverse types of spatial omics measurements (e.g., Visium, Slide-seq, MERFISH).
#'
#' The package provides a unified workflow extending the \pkg{Seurat} ecosystem, featuring:
#' \itemize{
#'   \item \strong{Niche Detection}: Robust algorithms to define spatial microenvironments based on cellular composition.
#'   \item \strong{Spatial Aggregation}: Metrics to quantify cell clustering and spatial organization.
#'   \item \strong{Contextual Interaction}: Enhanced ligand-receptor analysis incorporating spatial distance constraints.
#'   \item \strong{Advanced Visualization}: Specialized plotting functions for spatial maps, niche heatmaps, and interaction networks.
#' }
#'
#' See Yulong Qin et al. (Year) doi:10.xxxx/xxxxx for methodological details on niche detection,
#'
#' @section Package options:
#' STID uses the following \code{\link[base]{options}} to configure behaviour:
#'
#' \describe{
#'   \item{\code{STID.memsafe}}{
#'     Global option to call \code{gc()} after memory-intensive operations (e.g., large matrix permutations).
#'     This helps clean up the R session memory and prevents swap space usage.
#'     Defaults to \code{TRUE}. Setting to \code{FALSE} can speed up computation in high-RAM environments.
#'   }
#'   \item{\code{STID.parallel.threads}}{
#'     Controls the default number of threads for parallel operations (using \pkg{foreach} and \pkg{parallel}).
#'     Defaults to half of the available physical cores. Set to \code{1} to disable parallelization.
#'   }
#'   \item{\code{STID.warn.seurat.v5}}{
#'     Show warning if the input \pkg{Seurat} object is v5 format and specific v4-compatible layers are missing.
#'   }
#'   \item{\code{STID.check.dots}}{
#'     For functions that have \code{...} as a parameter, this controls the behavior when an argument isn't used.
#'     Can be one of \code{"warn"}, \code{"stop"}, or \code{"silent"}. Defaults to \code{"warn"}.
#'   }
#'   \item{\code{STID.msg.nichenet}}{
#'     Show message about using cached NicheNet networks to speed up initialization.
#'   }
#'   \item{\code{STID.msg.cellchat}}{
#'     Show message about the version of CellChatDB being loaded.
#'   }
#' }
#'
#' @author
#' \strong{Maintainer}: Yulong Qin \email{qyl3700@foxmail.com} (ORCID: 0009-0009-2761-0750)
#'
#' \strong{Contributors}:
#' \itemize{
#' }
#'
#' \strong{Funders}:
#' \itemize{
#' }
#'
#' @keywords internal
#' @seealso
#' Useful links:
#' \itemize{
#'   \item Homepage: \url{https://github.com/YulongQin/STID}
#'   \item Documentation: \url{https://YulongQin.github.io/STID/}
#'   \item Report bugs at \url{https://github.com/YulongQin/STID/issues}
#' }
#'
#' @references
#' If you use STID in your publication, please cite:
#' \itemize{
#'   \item YulongQin, et al. "STID: Spatial Transcriptomics toolkit for Infectious Diseases." \emph{Journal Name}, Year. DOI: 10.xxxx/xxxxx
#'   \item Stuart T, Butler A, et al. (2019) "Comprehensive Integration of Single-Cell Data." \emph{Cell}. doi:10.1016/j.cell.2019.05.031 (For Seurat foundation)
#' }
#'
#' @aliases STID-package STID
"_PACKAGE"
